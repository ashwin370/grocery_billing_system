from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # homepage
]
from django.urls import path
from . import views

urlpatterns = [
    path('', views.customer_info, name='customer_info'),
    path('customer/', views.customer_info, name='customer'),
    path('admin-login/', views.admin_login, name='admin_login'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('add-items/', views.add_items, name='add_items'),
    path('generate-bill/', views.generate_bill, name='generate_bill'),
    path('history/', views.customer_history, name='customer_history'),
    path('logout-admin/', views.logout_admin, name='logout_admin'),
    path('manage-items/', views.manage_items, name='manage_items'),
    path('edit-item/<int:item_id>/', views.edit_item, name='edit_item'),
    path('delete-item/<int:item_id>/', views.delete_item, name='delete_item'),
    path('sales-report/', views.sales_report, name='sales_report'),
    path('add-product/', views.add_product, name='add_product'),


]
