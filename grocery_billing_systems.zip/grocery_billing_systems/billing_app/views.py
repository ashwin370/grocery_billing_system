from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Sum
from django.utils.timezone import now
from datetime import timedelta
from .models import Customer, Item, Bill, BillItem




# ✅ Home
def home(request):
    return HttpResponse("✅ Grocery Billing System is connected and working!")

# ✅ Customer Info
def customer_info(request):
    if request.method == 'POST':
        name = request.POST['name']
        phone = request.POST['phone']
        customer = Customer.objects.create(name=name, phone=phone)
        request.session['customer_id'] = customer.id
        return redirect('add_items')
    return render(request, 'billing_app/customer_form.html')

# ✅ Add Items Page (Customer Side)
def add_items(request):
    items = Item.objects.all()
    if request.method == 'POST':
        cart = []
        for item in items:
            qty = request.POST.get(f'quantity_{item.id}', '0')
            try:
                qty = int(qty)
            except:
                qty = 0
            if qty > 0:
                cart.append({
                    'item_id': item.id,
                    'item_name': item.name,
                    'price': item.price,
                    'quantity': qty,
                    'total': qty * item.price
                })
        request.session['cart'] = cart
        return redirect('generate_bill')
    return render(request, 'billing_app/add_items.html', {'items': items})

# ✅ Generate Bill with Discount + Stock Update
def generate_bill(request):
    cart = request.session.get('cart', [])
    subtotal = sum(item['total'] for item in cart)

    if subtotal >= 2000:
        discount = subtotal * 0.15
    elif subtotal >= 1000:
        discount = subtotal * 0.10
    elif subtotal >= 500:
        discount = subtotal * 0.05
    else:
        discount = 0

    gst = subtotal * 0.18
    final_total = subtotal + gst - discount

    if request.method == 'POST':
        customer_id = request.session.get('customer_id')
        customer = Customer.objects.get(id=customer_id)
        bill = Bill.objects.create(customer=customer, total_amount=final_total)

        for c in cart:
            item = Item.objects.get(id=c['item_id'])
            BillItem.objects.create(
                bill=bill,
                item=item,
                quantity=c['quantity'],
                price=c['price']
            )
            item.stock -= c['quantity']
            item.save()

        return render(request, 'billing_app/generate_bill.html', {
            'cart': cart,
            'subtotal': subtotal,
            'gst': gst,
            'discount': discount,
            'final_total': final_total,
            'done': True
        })

    return render(request, 'billing_app/generate_bill.html', {
        'cart': cart,
        'subtotal': subtotal,
        'gst': gst,
        'discount': discount,
        'final_total': final_total,
        'done': False
    })

# ✅ Customer History
def customer_history(request):
    customer_id = request.session.get('customer_id')
    customer = Customer.objects.get(id=customer_id)
    bills = Bill.objects.filter(customer=customer).order_by('-date')
    return render(request, 'billing_app/customer_history.html', {
        'customer': customer,
        'bills': bills
    })

# ✅ Admin Login
def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == 'admin' and password == 'admin123':
            request.session['admin'] = True
            return redirect('admin_dashboard')
        else:
            return render(request, 'billing_app/admin_login.html', {'error': 'Invalid admin credentials'})
    return render(request, 'billing_app/admin_login.html')

# ✅ Admin Dashboard
def admin_dashboard(request):
    if not request.session.get('admin'):
        return redirect('customer_info')
    return render(request, 'billing_app/admin_dashboard.html')

# ✅ Logout Admin
def logout_admin(request):
    request.session['admin'] = False
    return redirect('customer_info')

# ✅ Manage Items
def manage_items(request):
    if not request.session.get('admin'):
        return redirect('customer_info')
    items = Item.objects.all()
    return render(request, 'billing_app/manage_items.html', {'items': items})

# ✅ Edit Item
def edit_item(request, item_id):
    item = get_object_or_404(Item, id=item_id)
    if request.method == 'POST':
        item.name = request.POST.get('name')
        item.price = float(request.POST.get('price'))
        item.stock = int(request.POST.get('stock'))
        item.save()
        return redirect('manage_items')
    return render(request, 'billing_app/edit_item.html', {'item': item})

# ✅ Delete Item
def delete_item(request, item_id):
    item = get_object_or_404(Item, id=item_id)
    item.delete()
    return redirect('manage_items')



# ✅ Sales Report
def sales_report(request):
    if not request.session.get('admin'):
        return redirect('customer_info')

    today = now().date()
    last_7_days = today - timedelta(days=7)

    daily_sales = (
        Bill.objects
        .filter(date__gte=last_7_days)
        .extra(select={'day': 'date(date)'})
        .values('day')
        .annotate(total=Sum('total_amount'))
        .order_by('day')
    )

    total_sales = Bill.objects.aggregate(total=Sum('total_amount'))['total'] or 0

    return render(request, 'billing_app/sales_report.html', {
        'daily_sales': daily_sales,
        'total_sales': total_sales
    })



def add_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_item')
    else:
        form = ItemForm()
    return render(request, 'billing_app/add_item.html', {'form': form})



def add_product(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')
        stock = request.POST.get('stock')

        if name and price and stock:
            try:
                price = float(price)
                stock = int(stock)
                Item.objects.create(name=name, price=price, stock=stock)
                messages.success(request, 'Item added successfully!')
                return redirect('add_product')
            except ValueError:
                messages.error(request, 'Invalid price or stock value.')
        else:
            messages.error(request, 'Please fill in all fields.')

    return render(request, 'billing_app/add_product.html')

def manage_items(request):
    items = Item.objects.all()
    return render(request, 'billing_app/manage_items.html', {'items': items})
